package org.se4940project.library_manager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagerApplication {

    public static void main(String[] args) {

        SpringApplication.run(LibraryManagerApplication.class, args);

    }

}
