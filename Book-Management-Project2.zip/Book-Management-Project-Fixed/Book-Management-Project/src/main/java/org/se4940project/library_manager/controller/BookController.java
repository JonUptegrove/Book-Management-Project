package org.se4940project.library_manager.controller;

import org.se4940project.library_manager.model.Book;
import org.se4940project.library_manager.repository.BookRepository;
import org.se4940project.library_manager.service.BookService;
import org.se4940project.library_manager.service.strategy.AuthorSearchStrategy;
import org.se4940project.library_manager.service.strategy.BookSearchStrategy;
import org.se4940project.library_manager.service.strategy.TitleSearchStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @Autowired
    private BookRepository bookRepository;

    // Handle book display
    @GetMapping
    public String listBooks(Model model) {
        model.addAttribute("books", bookService.getBooks());
        model.addAttribute("newBook", new Book());
        return "books";
    }

    // Handle book additions form
    @GetMapping("/add")
    public String showAddBookForm(Model model) {
        model.addAttribute("book", new Book());
        return "book-add";
    }

    // Process the form submission
    @PostMapping("/save")
    public String saveBook(@ModelAttribute Book book) {
        bookService.saveBook(book);
        return "redirect:/books";
    }

    // Display an individual book
    @GetMapping("/{id}")
    public String viewBook(@PathVariable Long id, Model model) {
        Book book = bookService.getBookById(id);
        if (book == null) {
            return "redirect:/books";
        }
        model.addAttribute("book", book);
        return "book-details";
    }

    @GetMapping("/search")
    public String searchBooks(@RequestParam(value = "query", defaultValue = "") String query,
                              @RequestParam(value = "searchType", defaultValue = "title") String searchType,
                              Model model) {
        BookSearchStrategy strategy;

        // Select strategy based on user input from the template dropdown
        if ("author".equalsIgnoreCase(searchType)) {
            strategy = new AuthorSearchStrategy();
        } else {
            strategy = new TitleSearchStrategy();
        }

        List<Book> books = strategy.search(bookRepository, query.trim());
        model.addAttribute("books", books);
        model.addAttribute("query", query);
        model.addAttribute("searchType", searchType);
        return "books";
    }
}
