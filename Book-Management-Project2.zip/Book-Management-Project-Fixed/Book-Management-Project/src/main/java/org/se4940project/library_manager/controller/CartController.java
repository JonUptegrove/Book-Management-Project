package org.se4940project.library_manager.controller;

import jakarta.servlet.http.HttpSession;
import org.se4940project.library_manager.model.Book;
import org.se4940project.library_manager.model.Cart;
import org.se4940project.library_manager.model.Member;
import org.se4940project.library_manager.service.BookService;
import org.se4940project.library_manager.service.facade.LibraryCheckoutFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

@Controller
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private Cart cart;

    @Autowired
    private BookService bookService;

    @Autowired
    private LibraryCheckoutFacade libraryCheckoutFacade;

    @PostMapping("/checkout")
    public String checkoutCart(@RequestParam(value = "memberId", required = false) Long memberId,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        // Resolve memberId from session if not explicitly sent or empty
        Member loggedInUser = (Member) session.getAttribute("loggedInUser");
        Long effectiveMemberId = (memberId != null) ? memberId : (loggedInUser != null ? (long) loggedInUser.getId() : null);

        if (effectiveMemberId == null) {
            redirectAttributes.addFlashAttribute("error", "Please log in to complete your checkout.");
            return "redirect:/login";
        }

        if (cart.getBooks().isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Your shopping cart is empty.");
            return "redirect:/cart";
        }

        // Build map of book IDs to requested quantities from the session Cart bean
        Map<Long, Integer> bookQuantities = new LinkedHashMap<>();
        for (Book book : cart.getBooks()) {
            bookQuantities.put(book.getId(), cart.getQuantity(book.getId()));
        }

        try {
            libraryCheckoutFacade.completeCheckoutWithQuantities(effectiveMemberId, bookQuantities);
            cart.clear();
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/cart";
        }

        return "redirect:/cart/confirmation";
    }

    // View the cart webpage
    @GetMapping
    public String viewCart(Model model, HttpSession session) {
        BigDecimal subtotal = BigDecimal.ZERO;

        for (Book book : cart.getBooks()) {
            int quantity = cart.getQuantity(book.getId());
            BigDecimal price = (book.getPrice() != null) ? book.getPrice() : BigDecimal.ZERO;
            BigDecimal bookTotal = price.multiply(BigDecimal.valueOf(quantity));
            subtotal = subtotal.add(bookTotal);
        }

        BigDecimal shippingCost = BigDecimal.ZERO;
        BigDecimal orderTotal = subtotal.add(shippingCost);

        Member loggedInUser = (Member) session.getAttribute("loggedInUser");
        Long currentMemberId = (loggedInUser != null) ? (long) loggedInUser.getId() : null;

        model.addAttribute("cartBooks", cart.getBooks());
        model.addAttribute("quantities", cart.getQuantities());
        model.addAttribute("subtotal", subtotal);
        model.addAttribute("shippingCost", shippingCost);
        model.addAttribute("orderTotal", orderTotal);
        model.addAttribute("currentMemberId", currentMemberId);

        return "cart";
    }

    // Add a book to the cart
    @PostMapping("/add/{id}")
    public String addToCart(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        Book book = bookService.getBookById(id);
        if (book != null) {
            int currentInCart = cart.getQuantity(id);
            boolean alreadyInCart = cart.getBooks().stream().anyMatch(b -> b.getId().equals(id));
            int nextQty = alreadyInCart ? currentInCart + 1 : 1;

            if (book.getStock() < nextQty) {
                redirectAttributes.addFlashAttribute("error", "Cannot add more copies of '" + book.getTitle() + "' than available in stock (" + book.getStock() + ").");
                return "redirect:/books/" + id;
            }
            cart.addBook(book);
        }
        return "redirect:/books";
    }

    // Remove a book from the cart
    @PostMapping("/remove/{id}")
    public String removeFromCart(@PathVariable Long id) {
        cart.removeBook(id);
        return "redirect:/cart";
    }

    // Clear all books from the cart
    @PostMapping("/clear")
    public String clearCart() {
        cart.clear();
        return "redirect:/cart";
    }

    // Change the quantity of a book
    @PostMapping("/quantity/{id}")
    public String updateQuantity(@PathVariable Long id,
                                 @RequestParam int quantity,
                                 RedirectAttributes redirectAttributes) {
        Book book = bookService.getBookById(id);
        if (book != null && quantity > book.getStock()) {
            redirectAttributes.addFlashAttribute("error", "Only " + book.getStock() + " copies of '" + book.getTitle() + "' are available.");
            cart.setQuantity(id, Math.max(1, book.getStock()));
            return "redirect:/cart";
        }
        cart.setQuantity(id, quantity);
        return "redirect:/cart";
    }

    // Navigate to payment page
    @GetMapping("/payment")
    public String payment(Model model) {
        if (cart.getBooks().isEmpty()) {
            return "redirect:/cart";
        }

        BigDecimal subtotal = BigDecimal.ZERO;
        for (Book book : cart.getBooks()) {
            int quantity = cart.getQuantity(book.getId());
            BigDecimal price = (book.getPrice() != null) ? book.getPrice() : BigDecimal.ZERO;
            subtotal = subtotal.add(price.multiply(BigDecimal.valueOf(quantity)));
        }

        BigDecimal shippingCost = BigDecimal.ZERO;
        BigDecimal orderTotal = subtotal.add(shippingCost);

        model.addAttribute("subtotal", subtotal);
        model.addAttribute("shippingCost", shippingCost);
        model.addAttribute("orderTotal", orderTotal);

        return "payment";
    }

    @PostMapping("/purchase")
    public String completePurchase(HttpSession session, RedirectAttributes redirectAttributes) {
        if (cart.getBooks().isEmpty()) {
            return "redirect:/cart";
        }

        Member loggedInUser = (Member) session.getAttribute("loggedInUser");
        if (loggedInUser == null) {
            redirectAttributes.addFlashAttribute("error", "Please log in to complete your purchase.");
            return "redirect:/login";
        }

        Map<Long, Integer> bookQuantities = new LinkedHashMap<>();
        for (Book book : cart.getBooks()) {
            bookQuantities.put(book.getId(), cart.getQuantity(book.getId()));
        }

        try {
            libraryCheckoutFacade.completeCheckoutWithQuantities((long) loggedInUser.getId(), bookQuantities);
            cart.clear();
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/cart";
        }

        return "redirect:/cart/confirmation";
    }

    @GetMapping("/confirmation")
    public String showConfirmation() {
        return "confirmation";
    }
}
