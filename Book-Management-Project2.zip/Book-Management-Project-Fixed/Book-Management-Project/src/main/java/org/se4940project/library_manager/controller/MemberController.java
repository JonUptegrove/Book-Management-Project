package org.se4940project.library_manager.controller;

import org.se4940project.library_manager.model.Member;
import org.se4940project.library_manager.repository.MemberRepository;
import org.se4940project.library_manager.service.MemberService;
import org.se4940project.library_manager.service.factory.MemberFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/members")
public class MemberController {

    @Autowired
    private MemberService memberService;

    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private MemberFactory memberFactory;

    // Handle user display
    @GetMapping
    public String listMember(Model model) {
        model.addAttribute("members", memberService.getMembers());
        model.addAttribute("newMember", new Member());
        return "members";
    }

    // Handle member additions via model attribute
    @PostMapping
    public String saveMember(@ModelAttribute Member member) {
        memberService.saveMember(member);
        return "redirect:/members";
    }

    @PostMapping("/add")
    public String addMember(@RequestParam("firstName") String fName,
                            @RequestParam("lastName") String lName,
                            @RequestParam("email") String email,
                            @RequestParam(value = "password", defaultValue = "password123") String password,
                            @RequestParam(value = "phoneNumber", defaultValue = "") String phoneNumber,
                            @RequestParam(value = "type", defaultValue = "USER") String type,
                            RedirectAttributes redirectAttributes) {
        if (memberRepository.findByUsername(email.trim()).isPresent()) {
            redirectAttributes.addFlashAttribute("error", "A member with that username/email already exists.");
            return "redirect:/members";
        }

        // Use the Factory pattern to instantiate the correct member subtype/role
        Member newMember = memberFactory.createMember(type, fName.trim(), lName.trim(), email.trim(), password, phoneNumber.trim());
        memberRepository.save(newMember);
        redirectAttributes.addFlashAttribute("success", "Member added successfully.");
        return "redirect:/members";
    }
}
