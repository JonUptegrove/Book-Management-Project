package org.se4940project.library_manager.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.se4940project.library_manager.model.Book;

import java.util.List;

public interface BookRepository extends JpaRepository<Book, Long> {
    List<Book> findByTitleContainingIgnoreCase(String title);
    List<Book> findByAuthorContainingIgnoreCase(String author);
}
