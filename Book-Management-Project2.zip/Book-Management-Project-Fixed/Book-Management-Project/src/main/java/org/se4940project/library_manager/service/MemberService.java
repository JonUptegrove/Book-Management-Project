package org.se4940project.library_manager.service;

import org.se4940project.library_manager.model.Member;
import org.se4940project.library_manager.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MemberService {
    @Autowired
    private MemberRepository memberRepo;

    // Retrieve members
    public List<Member> getMembers() {
        return memberRepo.findAll();
    }

    // Retrieve member by id
    public Member getMemberById(Long memberId) {
        if (memberId == null) {
            return null;
        }
        return memberRepo.findById(memberId).orElse(null);
    }

    // Save or update member
    public void saveMember(Member member) {
        memberRepo.save(member);
    }

    // Check login credentials safely (prevents NPE if member.getPassword() is null)
    public Member authenticate(String username, String password) {
        if (username == null || password == null) {
            return null;
        }
        Member member = memberRepo.findByUsername(username).orElse(null);
        if (member != null && member.getPassword() != null && member.getPassword().equals(password)) {
            return member;
        }
        return null;
    }
}
