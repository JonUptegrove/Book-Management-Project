package org.se4940project.library_manager.service.facade;

import org.se4940project.library_manager.model.Book;
import org.se4940project.library_manager.model.Member;
import org.se4940project.library_manager.service.BookService;
import org.se4940project.library_manager.service.MemberService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Component
public class LibraryCheckoutFacade {

    private final BookService bookService;
    private final MemberService memberService;

    public LibraryCheckoutFacade(BookService bookService, MemberService memberService) {
        this.bookService = bookService;
        this.memberService = memberService;
    }

    @Transactional
    public void completeCheckout(Long memberId, List<Long> bookIds) {
        if (memberId == null) {
            throw new IllegalArgumentException("Please log in before completing checkout.");
        }
        Member member = memberService.getMemberById(memberId);
        if (member == null) {
            throw new IllegalArgumentException("Invalid member ID: " + memberId);
        }
        if (bookIds == null || bookIds.isEmpty()) {
            throw new IllegalStateException("Your cart is empty.");
        }

        for (Long bookId : bookIds) {
            Book book = bookService.getBookById(bookId);
            if (book == null || book.getStock() <= 0) {
                throw new IllegalStateException("Book '" + (book != null ? book.getTitle() : bookId) + "' is out of stock.");
            }
            book.setStock(book.getStock() - 1);
            bookService.saveBook(book);
        }
    }

    @Transactional
    public void completeCheckoutWithQuantities(Long memberId, Map<Long, Integer> bookQuantities) {
        if (memberId == null) {
            throw new IllegalArgumentException("Please log in before completing checkout.");
        }
        Member member = memberService.getMemberById(memberId);
        if (member == null) {
            throw new IllegalArgumentException("Invalid member ID: " + memberId);
        }
        if (bookQuantities == null || bookQuantities.isEmpty()) {
            throw new IllegalStateException("Your cart is empty.");
        }

        for (Map.Entry<Long, Integer> entry : bookQuantities.entrySet()) {
            Long bookId = entry.getKey();
            int requestedQty = entry.getValue() != null ? entry.getValue() : 1;
            Book book = bookService.getBookById(bookId);

            if (book == null) {
                throw new IllegalStateException("Book with ID " + bookId + " no longer exists.");
            }
            if (requestedQty <= 0) {
                throw new IllegalStateException("Invalid quantity requested for '" + book.getTitle() + "'.");
            }
            if (book.getStock() < requestedQty) {
                throw new IllegalStateException("Insufficient stock for '" + book.getTitle() + "' (Available: " + book.getStock() + ").");
            }

            book.setStock(book.getStock() - requestedQty);
            bookService.saveBook(book);
        }
    }
}
