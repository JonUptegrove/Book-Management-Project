package org.se4940project.library_manager.service.factory;

import org.se4940project.library_manager.model.Member;
import org.springframework.stereotype.Component;

@Component
public class MemberFactory {

    public Member createMember(String type, String fName, String lName, String email) {
        return createMember(type, fName, lName, email, "password123", "");
    }

    public Member createMember(String type, String fName, String lName, String email, String password, String phoneNumber) {
        String normalized = (type == null) ? "USER" : type.toUpperCase().replace("ROLE_", "");
        String role = switch (normalized) {
            case "ADMIN" -> "ADMIN";
            case "LIBRARIAN" -> "LIBRARIAN";
            default -> "USER";
        };

        String safePassword = (password == null || password.isBlank()) ? "password123" : password;

        return Member.builder()
                .firstName(fName)
                .lastName(lName)
                .username(email)
                .password(safePassword)
                .phoneNumber(phoneNumber)
                .role(role)
                .build();
    }
}
