package org.se4940project.library_manager.service.strategy;

import org.se4940project.library_manager.model.Book;
import org.se4940project.library_manager.repository.BookRepository;
import java.util.List;

public class AuthorSearchStrategy implements BookSearchStrategy {
    @Override
    public List<Book> search(BookRepository bookRepository, String query) {
        return bookRepository.findByAuthorContainingIgnoreCase(query);
    }
}
